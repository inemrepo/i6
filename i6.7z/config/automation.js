module.exports.automation = {
	telegram : {
		token : '345035358:AAGedjlemWOYyscZsvmDthv4lvPGQmTBOkI'
	}
}