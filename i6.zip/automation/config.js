/*
 Urutan tugas yang di eksekusi
*/
module.exports.tasks = [
	'messenger',
	'tag',
	'device'
]