# i6

a [Sails](http://sailsjs.org) application
